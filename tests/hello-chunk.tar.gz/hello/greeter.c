#include <stdio.h>

int main(void)
{
    puts("greetings and salutations");
    return 0;
}
